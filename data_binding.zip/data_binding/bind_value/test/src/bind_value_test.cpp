//
//  (C) Copyright Brian Davis.
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Revision history:
//   19 July 2008
//		Created - to support and assist in dataflow and dataflow concepts
//

// This is not currently part of boost!  The only reason for the above copyright is to
// keep these concepts part of the boost development.  boost::data_binding is not
// officially part of boost.  The goal of this demo code is to elaborate on data binding
// and give a simple implementation and an example on how the concept can be applied within C++.

#include <iostream>
#include <boost/cstdint.hpp>
#include <boost/bind.hpp>
#include <boost/data_binding/bind_value.hpp>


#define MAX_CELSIUS 100
#define MIN_CELSIUS -17.8
#define MAX_RAW_SENSOR_COUNTS 4095

// use of a class is not necessary it is only shown to prove it is possible.  It may
// make more sense just to have conversion functions
class AClass_That_Is_A_Converter 
{
	public:
	protected:
		boost::data_binding::value<boost::uint32_t> rawCelsiusCountsFromSensor;
		boost::data_binding::value<float> calibratedCelsiusDataFromSensor;
		boost::data_binding::value<float> calibratedFahrenheit;
		
        boost::uint32_t rawSensorValue;
        float fahrenheit;
        float celsius;
        
		
		boost::data_binding::bind_values<float, boost::uint32_t> mv_celsiusToSensorBinder;
		boost::data_binding::bind_values<float, float> mv_celsiusToFahrenheitBinder;

	private:

	public:
		AClass_That_Is_A_Converter( void ) : 
            rawCelsiusCountsFromSensor(rawSensorValue),
            calibratedCelsiusDataFromSensor(celsius),
            calibratedFahrenheit(fahrenheit),
			mv_celsiusToSensorBinder
			( 
				calibratedCelsiusDataFromSensor, rawCelsiusCountsFromSensor,
				boost::bind( &AClass_That_Is_A_Converter::convertCelsiusRawToCalibrated, this, _1, _2 ),
				boost::bind( &AClass_That_Is_A_Converter::convertCelsiusCalibratedToRaw, this, _1, _2 )
			),
			mv_celsiusToFahrenheitBinder
			( 
				calibratedCelsiusDataFromSensor, calibratedFahrenheit,
				boost::bind( &AClass_That_Is_A_Converter::convertFahrenheitToCelsius, this, _1, _2 ),
				boost::bind( &AClass_That_Is_A_Converter::convertCelsiusToFahrenheit, this, _1, _2 )
			)
		{}
        
        
		virtual ~AClass_That_Is_A_Converter( void ){}
		
		void test( void )
		{
            std::cout << "Starting test of data binding" << std::endl;
            try
            {
                std::cout<< "Note raw temp represents the raw value of an Analog to Digital Converter" << std::endl;
                std::cout<< "The range is from 0-4095 which represents -17.8 - 100 degrees on the Celsius" << std::endl;
                std::cout<< "scale and 0 - 212 degrees on the Fahrenheit" << std::endl;

                std::cout<< "Setting calibratedFahrenheit to 70.0 degrees fahrenheit" << std::endl;
                std::cout<< "calibratedFahrenheit = 70.0f;" << std::endl;
                calibratedFahrenheit = 70.0f;
                std::cout << "What does the celsius value contain? ... should be ~21.1" << std::endl;
                showValues();                       

                std::cout << "Now change the raw sensor value and see what happens to Celsius and Fahrenheit" << std::endl;
                std::cout<< "rawCelsiusCountsFromSensor = 4095;" << std::endl;
                rawCelsiusCountsFromSensor = 4095;
                std::cout << "Celsius should equal ~100" << std::endl;
                std::cout << "Fahrenheit should equal ~212" << std::endl;
                showValues();                       
                
                
                std::cout << "Now change celsius see what happens to raw and farenheit" << std::endl;
                std::cout<< "calibratedCelsiusDataFromSensor = 32.2;" << std::endl;
                calibratedCelsiusDataFromSensor = 32.2;
                std::cout << "Fahrenheit should equal ~90 degress" << std::endl;
                showValues();                       


                std::cout << "Note changing original values will not have any affect in C++ " << std::endl;
                std::cout << "this makes me sad :-( as a class wrapper and operator overloading" << std::endl;
                std::cout << "is necessary... without changing the compiler... hint.... hint..." << std::endl;
                std::cout << "fahrenheit = 10;" << std::endl;
                fahrenheit = 10;
                showValues();   
                std::cout << "No change in values :-( !!!" << std::endl;
                    
                
                
                // Note one to many fanout is possible and the example shows 1 to 2 fanout with Celsius 
                // fanning out to Raw and Fahrenheit values.  A more advanced implementation is also possible 
                // which includes the use of the lamda library and place holders.  This is just a simple 
                // example which I hope will "prime the pump" for work on a data_binding library with in 
                // the Boost development.  Most direct use for this library is within data_flow library.
                // Another use is within the cppgui library which would allow modification of data to directly
                // affect values of UI controls and display values.
                
            }
            catch( std::exception& ex )
            {
                std::cout << "Failed with exception: " << ex.what();    
            }			
            std::cout << "End of data binding test" << std::endl;

		}
		
		void showValues( void )
		{
            std::cout << std::endl;
            std::cout << "Fahrenheit                            : " << calibratedFahrenheit << std::endl;    
            std::cout << "Celsius                               : " << calibratedCelsiusDataFromSensor << std::endl;    
            std::cout << "Raw Temp To/From Sensor A/D converter : " << rawCelsiusCountsFromSensor << std::endl;
            std::cout << std::endl;
            std::cout << "fahrenheit                            : " << fahrenheit << std::endl;    
            std::cout << "celsius                               : " << celsius << std::endl;
            std::cout << "rawSensorValue                        : " << rawSensorValue << std::endl;    
            std::cout << std::endl;
            std::cout << "====================================================================" << std::endl;
        }
            
    protected:
        float& convertFahrenheitToCelsius
        ( 
            float& celsius , float& fahrenheit 
        )
        {
            return celsius = ((fahrenheit - 32.0) * 5.0) / 9.0;
        }
        
        float&  convertCelsiusToFahrenheit
        (
            float& fahrenheit, float& celsius 
        )
        {
            return fahrenheit = celsius * (9.0 / 5.0) + 32.0;
        }


        float& convertCelsiusRawToCalibrated
        ( 
            float& calibratedValue,  boost::uint32_t& rawValue 
        )
        {
            return calibratedValue = ( MAX_CELSIUS - MIN_CELSIUS ) * (rawValue / MAX_RAW_SENSOR_COUNTS) + MIN_CELSIUS;
        }


        boost::uint32_t& convertCelsiusCalibratedToRaw
        ( 
            boost::uint32_t& rawValue, float& calibratedValue 
        )
        {
            // Raw is from 0  to 4095 ( a 12 bit number of an 
            // Analog to Digital converter
            // map zero (fahrenheit) to water boiling to raw value of 4095 
            return  rawValue = MAX_RAW_SENSOR_COUNTS * ( calibratedValue - MIN_CELSIUS) / ( MAX_CELSIUS - MIN_CELSIUS );
        } 


       
        
    private:
    
};






int main(int argc, char **argv) 
{
    
    AClass_That_Is_A_Converter anExampleOfDataBinding;

    anExampleOfDataBinding.test();
            
}







