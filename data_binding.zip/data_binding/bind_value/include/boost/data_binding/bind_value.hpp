//
//  (C) Copyright Brian Davis.
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
// Revision history:
//   19 July 2008
//      Created - to support and assist in dataflow and dataflow concepts
//

// This is not currently part of boost!  The only reason for the above copyright is to
// keep these concepts part of the boost development.  boost::data_binding is not
// officially part of boost.  The goal of this demo code is to elaborate on data binding
// and give a simple implementation and an example on how the concept can be applied within C++.

#ifndef BOOST_DATA_BINDING_HPP

#include <boost/cast.hpp>
#include <boost/function.hpp>
#include <boost/bind.hpp>
#include <boost/foreach.hpp>
#include <vector>
namespace boost { namespace data_binding { 
	
template < class T1, class T2> class bind_values;
    
template <class T>
class value
{
    friend class bind_values< class T1, class T2>; 
	public:
		typedef boost::function< T& (T&) > set_value_function;
		std::vector<set_value_function> set_value_functions;
        T& mv_value;
        // To prevent infinite recursion on a group of three linked variables a->b->c->a.
        bool mv_entered;
	protected:
	private:	
	
	public:
		value( T& invalue ) : mv_value( invalue ){ mv_entered = false; };
	
        // Sets require action event handling to update value of binded type.. gets are transparent
		value& operator=( T& rhs  )
		{
			if( set_value_functions.size() && !mv_entered ) 
			{
                mv_entered = true;
				BOOST_FOREACH( set_value_function set_value, set_value_functions )
                {
                    mv_value = set_value( rhs );
                }	
			}
			else
			{
				// Otherwise simple type cast convert
				mv_value = boost::numeric_cast<T>( rhs );
			}
            mv_entered = false;

            return *this;
		}

        value& operator=( T rhs  )
        {
        
            if( set_value_functions.size() && !mv_entered ) 
            {
                mv_entered = true;
                BOOST_FOREACH( set_value_function set_value, set_value_functions )
                {
                    mv_value = set_value( rhs );
                }   
            }
            else
            {
                // Otherwise simple type cast convert
                mv_value = boost::numeric_cast<T>( rhs );
            }
            mv_entered = false;
            return *this;
        }

        void add_set_function( set_value_function set_function )
        {
            set_value_functions.push_back( set_function );    
        }

        
        T& operator&( value<T>& value )
        {
            return value.mv_value;    
        }


           	
	protected:
	private:	
	
	
};




template < class T1, class T2>
class bind_values
{
    friend class value<T1>;
    friend class value<T2>;
	public:
		typedef T1 type1;
        typedef T2 type2;
        typedef boost::function< T1& (T1, T2)> convert_to_function;
		typedef boost::function< T2& (T2, T1)> convert_from_function;
		convert_to_function convert_to;
		convert_from_function convert_from;
	protected:
        value<T1>& mv_value1;
        value<T2>& mv_value2;



	private:	
	
	public:
		bind_values
		( 
			value<T1>& value1, value<T2>& value2, 
			convert_to_function convertTo, convert_from_function convertFrom
		) : 
			convert_to(convertTo), convert_from(convertFrom),
            mv_value1( value1 ), mv_value2( value2 )
        {
            // Hook up set for value 1
            mv_value1.add_set_function( boost::bind( &bind_values::set_value1, this, _1 ) );                            

            // Hook up set for value 2
            mv_value2.add_set_function( boost::bind( &bind_values::set_value2, this, _1 ) );                            
        } 

        bind_values( value<T1>& value1, value<T2>& value2 ) : 
            mv_value1( value1 ), mv_value2( value2 ) 
        {
            // Hook up set for value 1
            mv_value1.set_value = boost::bind( &bind_values::set_value1, _1 );                            

            // Hook up set for value 2
            mv_value2.set_value = boost::bind( &bind_values::set_value2, _1 );                            
        }



    protected:
        T1& set_value1( T1& value )
        {
            if( convert_from )
            {
                 // Convert and set value 2 
                 mv_value2 = boost::numeric_cast<T2>( convert_from( mv_value2.mv_value, value ) );
            }
            else
            {
                // Otherwise simple type cast convert
                mv_value2 = boost::numeric_cast<T2>( value );
            }
            // return the value unmodified to the original container                 
            return value;
                    
        }
        
        T2& set_value2( T2& value )
        {
            if( convert_to )
            {
                 // Convert and set value 1 
                 mv_value1 = boost::numeric_cast<T1>( convert_to( mv_value1.mv_value, value ) );
            }
            else
            {
                // Otherwise simple type cast convert
                mv_value1 = boost::numeric_cast<T1>( value );
            }
            // return the value unmodified to the original container                 
            return value;
                    
        }

    
    
    private:    
    
};

} } // namespace boost::data_binding


template <class T>
std::ostream& operator<<( std::ostream& os, boost::data_binding::value<T>& rhs )
{
    os << rhs.mv_value;;
    return os;
}


#endif
